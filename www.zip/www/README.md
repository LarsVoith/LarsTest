# debugApp
For debugging cordova/phonegap apps
